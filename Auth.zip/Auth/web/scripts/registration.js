//function registrationForm() {
//    document.getElementById("sendRegistrationData").addEventListener('click', () => {
//        const avatar = document.querySelector('input[name=avatar]');
//        if (avatar.files.length > 0) {
//            const data = new FormData();
//            data.append('avatar', avatar.files[0]);
//            const x = new XMLHttpRequest();
//            x.open('POST', '/Auth/api/user', true);
//            x.send(data);
//            x.onload = () => {
//                console.log(x.responseText);
//                const j = JSON.parse(x.responseText);
//                if (j.status < 0) {
//                    alert(j.msg);
//                }
//                if (j.status == 1) { // Аватар передан в поле msg имя файла
//                    sendStringData(j.msg);
//                }
//            }
//        } else {
//            sendStringData();
//
//        }
//    });
//}
//
//function sendStringData(fname) {
//    const login = document.getElementById("login").value;
//    const pass1 = document.getElementById("pass1").value;
//    const pass2 = document.getElementById("pass2").value;
//    const name = document.getElementById("name").value;
//    const email = document.getElementById("email").value;
//
//
//    var sendData = {
//        login: login,
//        pass1: pass1,
//        pass2: pass2,
//        name: name,
//        email: email
//    };
//    if (fname) {
//        sendData.fname = fname;
//    }
//    fetch('/Auth/api/user', {
//        method: "POST",
//        body: JSON.stringify(sendData),
//        headers: {
//            "Content-Type": "application/json"
//        }
//    }).then(r => r.text()).then(console.log);
//}
//
//async  function goToReg() {
//    const goReg = document.getElementById("registrationButtonForm2");
//    goReg.addEventListener('click', () => {
//        forwardRegistration();
//    })
//}
