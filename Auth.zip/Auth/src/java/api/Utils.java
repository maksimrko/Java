package api;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import static jdk.nashorn.internal.objects.NativeMath.random;
import org.apache.commons.lang3.RandomStringUtils;

public class Utils {

//    public static String MD5(String str) {
//        try {
//            byte[] s_bin = str.getBytes("UTF-8");
//            MessageDigest md = MessageDigest.getInstance("MD5");
//            byte[] h_bin = md.digest(s_bin);
//            BigInteger num = new BigInteger(1, h_bin);
//            String hash = num.toString(16);
//            while (hash.length() < 32) {
//                hash = "0" + hash;
//            }
//            return hash;
//        } catch (Exception ex) {
//
//        }
//
//        return str;
//    }

//    public static String getPassHash(String pass) throws NoSuchAlgorithmException, UnsupportedEncodingException {
//        MessageDigest md = MessageDigest.getInstance("MD5");          
//        md.update(pass.getBytes("UTF-8"));
//        byte[] hash = md.digest();
//        BigInteger num = new BigInteger(1, hash);        
//        return num.toString(16);
//    }

    public static String Random(String rand) {
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //ПРОСТО РАНДОМ
//        SecureRandom secureRandom = new SecureRandom();
//        //String asd2="asdsa";
//        rand = String.valueOf(secureRandom.nextBytes(d));
//        return rand;
//        
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //бУКВЕННО ЦИФРОВАЯ
//        int leftLimit = 97; // letter 'a'
//   int rightLimit = 122; // letter 'z'
//        int targetStringLength = 10;
//        Random random = new Random();
//
//        rand = random.ints(leftLimit, rightLimit + 1)
//                .limit(targetStringLength)
//                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
//                .toString();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //APACHE COMMON Lang         
        // rand = RandomStringUtils.randomAlphanumeric(32);// ЦИФРЫ И БУКВЫ
        //rand = RandomStringUtils.randomAlphabetic(25);// БУКВЫ
        //rand = RandomStringUtils.randomAscii(25);// БУКВЫ
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        int leftLimit = 48; // numeral '0'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 32;
        Random random = new Random();

        rand = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
        return rand;
    }
}
//md5       
//        MessageDigest md = null;
//        try {
//            md = MessageDigest.getInstance("MD5");
//        } catch (NoSuchAlgorithmException ex) {
//            resp.getWriter().print("{\"status\":-4,\"msg\":\"Security error:Alg not found\"}");
//            return;
//        }       
//        md.update(pass1.getBytes("UTF-8"));
//        byte[] hash = md.digest();
//        BigInteger num = new BigInteger(1, hash);
//        String passHash = num.toString(16);
