package api;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Random;
import java.util.regex.Pattern;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import orm.UserData;

public class User extends HttpServlet {

    String status;
    //ResultSet res;
    private Connection con;
    Statement stmt;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        boolean textMode;

        //Action File        
        Part avatar = null;
        try {
            avatar = req.getPart("avatar");
            textMode = false;
        } catch (Exception e) {
            // Нет передачи файла только текстовые данные
            textMode = true;
            //  resp.getWriter().print(e.getMessage());           
        }
        if (textMode) {

//        String body = "";
//        Scanner scanner = new Scanner(req.getInputStream());
//        while (scanner.hasNext()) {
//            body += scanner.next();
//        }
//        resp.getWriter().print(body);
//        JSONParser parser;
            JsonReader jr = Json.createReader(req.getInputStream());// servlet
            JsonObject jo = jr.readObject();

            String login = null, pass1 = null, pass2 = null, name = null, email = null, avatarName = null;
            //Intgerity checking - is all data in request
            try {
                login = jo.getString("login");//from json date servelet
                pass1 = jo.getString("pass1");
                pass2 = jo.getString("pass2");
                name = jo.getString("name");
                email = jo.getString("email");
            } catch (Exception ex) {
                resp.getWriter().print("{\"status\":-1,\"msg\":\"Data ingertity broken\"}");
                return;
            }
            try {
                avatarName = jo.getString("fname");
            } catch (Exception e) {
            }

            ///////////////////Data format checking///////////////////////////////////////////////       
            if (login.length() < 2) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error:login too short\"}");
                return;
            }

            if (!pass1.equals(pass2)) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error:passwords mismat\"}");
                return;
            }
            if (pass1.length() < 3 ) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error:password too short\"}");
                return;
            }
            if (name.length() < 2) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error:name too short\"}");
                return;
            }

            if (email.length() < 6) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error:email too short\"}");
                return;
            }
            String emailPattern = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
            if (!Pattern.matches(emailPattern, email)) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error:email has improper format\"}");
                return;
            }

            if (UserData.registerUser(login, pass2, name, email, avatarName)) {
                resp.getWriter().print("{\"status\":1,\"msg\":\"Insert OK\"}");

            } else {
                resp.getWriter().print("{\"status\":-3,\"msg\":\"Registration error:not found image\"}");

            }
        } ////////////////////////////////////////////ЗАГРУЗКА ФАЙЛОВ ПОСЛЕ TEXTMODE///////////////////////////////////////////////////////////////////////////////////////////////////////        
        else { // if! textMode -Загрузка файлов            
            String path = getServletContext().getRealPath("."); // build\web
            path += "/../../web/avatar/";

            String submittedFileName = avatar.getSubmittedFileName();
            //Проверить на существованние файла
            int dotIndex = submittedFileName.lastIndexOf('.');
            if (dotIndex < 1) {
                resp.getWriter().print("{\"status\":-7,\"msg\":\"File transfer error: not extension\"}");
                return;
            }
            String extension = submittedFileName.substring(dotIndex);
            if (!(extension.equals(".jpg")
                    || extension.equals(".png"))) {
                resp.getWriter().print("{\"status\":-7,\"msg\":\"File transfer error: Unssported  extension\"}");
                return;
            }
            //
            String fname;
            Random rnd = new Random();
            File file;
            do {
                //fname = Utils.Random(path) + extension; // Длинное название картинки с буквами и цифрами + расширение 
                fname = rnd.nextInt() + extension; // только цифры
                file = new File(path, fname);
            } while (file.exists());
            try {
                Files.copy(
                        avatar.getInputStream(),
                        new File(path, fname).toPath(),
                        StandardCopyOption.REPLACE_EXISTING
                );
            } catch (IOException ex) {
                resp.getWriter().print("{\"status\":-6,\"msg\":\"" + ex.getMessage() + "\"}");
            }
            resp.getWriter().print("{\"status\":1,\"msg\":\"" + fname + "\"}");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        //Mode - userdata by id
        String reqUserId = req.getParameter("userId");
        if (reqUserId != null) {
            //Обеспечить проверку regUesrId на проверку числа
            int uid;
            try {
                uid = Integer.parseInt(reqUserId);
            } catch (Exception ex) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error user ID\"}");
                return;
            }
            //Проверка успешности преобразования строки в число
            if (uid == 0) {
                resp.getWriter().print("{\"status\":-2,\"msg\":\"Data format error user ID\"}");
                return;
            }

            // <editor-fold defaultstate="collapsed" desc="Connection database query table user">
            //Connect to database
//            try {
//                con = Db.getConnection();
//            } catch (Exception e) {
//                resp.getWriter().print("{\"status\":-3,\"msg\":\"" + e.getMessage() + "\"}");
//                return;
//            }
            //``йо кавычки в sql именные исп для форм имени (аля $php)переменная показываем границы имени позв сказать субд это имя,воспр это как имя в бз
            //1-й метод запроса из таблицы данных юзера
//            try {
//                // Результатом запроса является таблица  если успешно срабатывает то мы попадаем в res.next(), 
//                ResultSet res = con.createStatement().executeQuery(
//                        "SELECT `name`,`login` ,`email`,`avatar` FROM `users` WHERE `id` = " + uid
//                );
//                /*
//                 next считывание result переносит на следующую строку. перекачка результата см.выще в (fetch)перевод каретки               
//                строчку таблицы  в ressult res и передает даные строки res сюда
//                 */
//                if (res.next()) {
//                    
//                    String avatar=res.getString(4);
//                    JsonObject udata = Json.createObjectBuilder()
//                            .add("status", 1)//res это result выще, вычитывание из запроса
//                            .add("name", res.getString(1))//res это result выще, вычитывание из запроса
//                            .add("login", res.getString(2))
//                            .add("email", res.getString(3))
//                            .add("avatar", (avatar==null)?"":avatar)
//                            .build();
//                    resp.getWriter().print(udata.toString());
//                    return;
//                }                 
//                
//                else {
//                    resp.getWriter().print("{\"status\":-6,\"msg\":\"Access denied\"}");
//                }
//            }
// </editor-fold>
            orm.UserData user = orm.UserData.getbyId(uid);
            if (user == null) {
                resp.getWriter().print("{\"status\":-6,\"msg\":\"Access denied\"}");
            } else {
                resp.getWriter().print("{\"status\":1, \"user\":" + user.toJsonString() + "}");
            }
            return;
        }

        ////////////////////////////////////////////////////////////////////////
        //Mode - id by Login/password
        String login = null, password = null;

        try {
            login = req.getParameter("login");
            password = req.getParameter("password");
        } catch (Exception ex) {
            resp.getWriter().print("{\"status\":-1, \"msg\":\"" + ex.getMessage() + "\"}");
            return;
        }

        if (login == null
                || login.length() == 0
                || password == null
                || password.length() == 0) {
            resp.getWriter().print("{\"status\":-1, \"msg\":\"Data format error: empty value(s)\"}");
            return;
        }

        orm.UserData user = orm.UserData.getByLoginPassword(login, password);
        if (user == null) {
            resp.getWriter().print("{\"status\":-6,\"msg\":\"Access denied\"}");
        } else {
            resp.getWriter().print("{\"status\":1, \"user\":" + user.toJsonString() + "}");
        }
        return;

        // <editor-fold defaultstate="collapsed" desc="Запрос к базе данных">
//        try {
//            con = Db.getConnection();
//        } catch (Exception e) {
//            resp.getWriter().print("{\"status\":-3,\"msg\":\"" + e.getMessage() + "\"}");
//            return;
//        }
//        String passHash = null;
//        orm.UserData md5Hash = null;
//        try {
//            passHash = md5Hash.getPassHash(password);
//        } catch (Exception ex) {
//            resp.getWriter().print("{\"status\":-4,\"msg\":\"Security error:Algorithm/Encoding not found\"}");
//        }
//        int userId = -1;
//
//        ////////////////////////////Обычный запрос///////////////////////////////////////////////
//        //  String query = "SELECT id FROM `users` WHERE `login` LIKE '" + login + "' AND `pass_hash` LIKE '" + passHash + "'";      
//        /*try {
//            ResultSet res = con.createStatement().executeQuery(query);
//            if (res.next()) {
//                userId = res.getInt(1);
//            }
//        } catch (SQLException ex) {
//            resp.getWriter().print("{\"status\":-3,\"msg\":\"" + ex.getMessage() + "\"}");
//            return;
//        }*/
//        /////////////////////////////////////////////////////////////////////////
//        //Sql injection запрос Использование  like ищет по шаблону -  символ % заменяет группу символов 
//        // String query = "SELECT id FROM `users` WHERE `login` LIKE ? AND `pass_hash` Like ?";
//        String query = "SELECT id FROM `users` WHERE `login` = ? AND `pass_hash` = ?";
//
//        try {
//            PreparedStatement prep = con.prepareStatement(query);
//            prep.setString(1, login);
//            prep.setString(2, passHash);
//            ResultSet res = prep.executeQuery();
//            if (res.next()) {
//                userId = res.getInt(1);
//            }
//        } catch (SQLException ex) {
//            resp.getWriter().print("{\"status\":-3,\"msg\":\"" + ex.getMessage() + "\"}");
//            return;
//        }
//        if (userId
//                == -1) {
//            resp.getWriter().print("{\"status\":-6,\"msg\":\"Access denided\"}");
//        } else {
//            resp.getWriter().print("{\"status\":1,\"msg\":\"" + userId + "\"}");
//        }
        /* Sql Injection Homework
        1.Ограничить ввод - не разшерать спецсимволы
        2.Экранирование - добавление \ перед рядом символов // замена на подобные символы
        3.Подготовленные запросы        
         */
        // </editor-fold>
    }

}
