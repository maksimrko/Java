package api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Db {

    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String PASS = "auth_pass";
    private static final String USER = "auth_user";
    private static final String NAME = "auth_java";
    private static final String CHAR = "UTF-8";
    private static Connection con;

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        if (con == null) {
            Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://" + HOST + ":" + PORT + "/" + NAME + "?characterEncoding=" + CHAR, USER, PASS);
        }
        return con;
    }

    private Db() {

    }
}
