package orm;
// ORM- Object mapping relation
//Db table -language objects

import api.Db;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import javax.json.Json;
import javax.json.JsonObject;

//mapping 
public class UserData {

    //отображение в базе
    int id;
    String login;
    String passHash;
    String name;
    String email;
    String avatar;
    private static Connection con;

    public static boolean registerUser(String login, String password, String name, String email, String avatar) {
      // 1. Connection
        try{
            con = Db.getConnection() ;            
        } catch( Exception ex ) {
            return false ;
        }

        // 1.5. Checking if login in DB
        int n = -1;
        String checkLogin = "SELECT COUNT(id) FROM users WHERE `login` LIKE ?" ;
        try {
            PreparedStatement p2 = con.prepareStatement( checkLogin ) ;
            p2.setString( 1, login ) ;
            ResultSet res = p2.executeQuery() ;
            res.next();
            n = res.getInt( 1 ) ;
        } catch( SQLException ex ) {
            return false ;
        }
        if( n > 0 ) {
            return false ;
        }

        // 2. Send insert query
        // 2.1. Preparing
        String query = "INSERT INTO users ( `login` , `pass_hash`, `name`, `email`, `avatar` ) VALUES( ?, ?, ?, ?, ? )" ;
        PreparedStatement prep ;
        try {
            prep = con.prepareStatement( query ) ;
        } catch( SQLException ex ) {
            return false ;
        }
        // 2.2. Data binding        
        String passHash = null ;
        try {
            passHash = getPassHash( password ) ;
        } catch( Exception ex ) {
            return false ;
        }
        try {
            prep.setString( 1, login ) ;
            prep.setString( 2, passHash ) ;
            prep.setString( 3, name  ) ;
            prep.setString( 4, email ) ;
            if( avatar != null )  prep.setString( 5, avatar ) ;
            else prep.setNull( 5, Types.VARCHAR ) ;

        } catch( SQLException ex ) {
            return false ;
        }
        // 2.3. Executing
        try {
            prep.executeUpdate() ;
        } catch( SQLException ex ) {
            return false ;
        }
        return true ;

        } 
    

    public UserData(int id, String login, String passHash, String name, String email, String avatar) {
        this.id = id;
        this.login = login;
        this.passHash = passHash;
        this.name = name;
        this.email = email;
        this.avatar = avatar;
    }

    //обэкт достаем из базы,создает обэкт     
    public static UserData getbyId(int uid) {
        //Connect to database
        try {
            con = Db.getConnection();
        } catch (Exception e) {
            return null;
        }

        try {
            // Результатом запроса является таблица  если успешно срабатывает то мы попадаем в res.next(), 
            ResultSet res = con.createStatement().executeQuery(
                    "SELECT `login` ,`pass_Hash`,`name`,`email`,`avatar` FROM `users` WHERE `id` = " + uid
            );
            /*
                 next считывание result переносит на следующую строку. перекачка результата см.выще в (fetch)перевод каретки               
                строчку таблицы  в ressult res и передает даные строки res сюда
             */
            if (res.next()) {
                String avatar = res.getString(5);
                return new UserData(uid,
                        res.getString(1),
                        res.getString(2),
                        res.getString(3),
                        res.getString(4),
                        (avatar == null) ? "" : avatar
                );
            } else {
                return null;
            }
        } catch (SQLException ex) {
            return null;
        }
    }

    public static UserData getByLoginPassword(String login, String password) {
        try {
            con = Db.getConnection();
        } catch (Exception e) {
            return null;
        }
        String passHash = null;
//        orm.UserData md5Hash = null;
        try {
            passHash = getPassHash(password);
        } catch (Exception ex) {
            return null;
        }

        //Sql injection запрос Использование  like ищет по шаблону -  символ % заменяет группу символов 
        // String query = "SELECT id FROM `users` WHERE `login` LIKE ? AND `pass_hash` Like ?";
        String query = "SELECT id, `name`, `email`, `avatar` FROM `users` WHERE `login` = ? AND `pass_hash` = ?";

        try {
            PreparedStatement prep = con.prepareStatement(query);
            prep.setString(1, login);
            prep.setString(2, passHash);
            ResultSet res = prep.executeQuery();
            if (res.next()) {
                // userId = res.getInt(1);
                String avatar = res.getString(4);
                return new UserData(
                        res.getInt(1),
                        login,
                        passHash,
                        res.getString(2),
                        res.getString(3),
                        (avatar == null) ? "" : avatar
                );
            } else {
                return null;

            }
        } catch (SQLException ex) {
            return null;
        }
    }

    public String toJsonString() {
        //данные конвертятся тустринг с конкретными данными 
        return Json.createObjectBuilder()
                .add("id", id)//res это result выще, вычитывание из запроса
                .add("name", name)
                .add("email", email)//res это result выще, вычитывание из запроса              
                .add("login", login)
                .add("avatar", (avatar == null) ? "" : avatar)
                .build().toString();
    }

    public static String getPassHash(String pass) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(pass.getBytes("UTF-8"));
        byte[] hash = md.digest();
        BigInteger num = new BigInteger(1, hash);
        return num.toString(16);
    }

}
