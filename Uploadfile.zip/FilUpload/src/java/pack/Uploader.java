package pack;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

public class Uploader extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        //Данные - мультипар -их части - парты
        Part file;
        try {
            file = req.getPart("avatar"); //<input> from index.html
        } catch (Exception e) {
            resp.getWriter().print(e.getMessage());
            return;
        }
        String fileName = file.getSubmittedFileName();
        // resp.getWriter().print(fileName);
        // resp.getWriter().print(file.getHeader("Content-Disposition").split("filename=")[1].replace("\"", ""));
        // resp.getWriter().print(file.getHeader("Content-Disposition"));
        if ("".equals(fileName)) {
            resp.getWriter().print("No file selected");
        }
        String path;
        // path = new File(".").getCanonicalPath();// Текущий каталог
        path = getServletContext().getRealPath("./../../uploaded");
       // resp.getWriter().print(path);
        File stored = new File(path, fileName);
        try {
            Files.copy(
                    file.getInputStream(),
                    stored.toPath(),
                    StandardCopyOption.REPLACE_EXISTING
            );
        } catch (IOException e) {
            resp.getWriter().print(e.getMessage());
        }
        resp.getWriter().print(fileName + " Uploaded");
        
        try{
        // Text input data 
        String descr = req.getParameter("description"); // имя параметра - имя input
       // String descr2= new  String(descr.getBytes(StandardCharsets.ISO_8859_1),StandardCharsets.UTF_8);
        //resp.getWriter().print( " description "+descr+descr2);
        resp.getWriter().print( " description "+descr);
        
        }
        catch(Exception ex){}
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }

}
